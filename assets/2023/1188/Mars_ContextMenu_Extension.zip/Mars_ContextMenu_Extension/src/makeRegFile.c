#include<stdio.h>
int main(int num,char **argv){
	if(num!=2) return 1;
	printf("Windows Registry Editor Version 5.00\n\n[HKEY_CLASSES_ROOT\\Directory\\Background\\shell\\%s\\command]\n@=\"",argv[1]);
	int c;
	while(1){
		c=getchar();
		if(c==EOF||c=='\n') break;
		if(c=='\\'||c=='\"') putchar('\\');
		putchar(c);
	}
	puts("\"\n");
	return 0;
}
