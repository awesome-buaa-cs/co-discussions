import os
import difflib
import zipfile
import func_timeout
from func_timeout import func_set_timeout
from threading import Thread
import time
import shutil 


MAXN = 10000
tbtxt5 = """`timescale 1ns / 1ps
module generated_mips_test;
	reg clk; 
	reg reset;
	mips uut (
		.clk(clk), 
		.reset(reset) 
	);
	initial begin
		clk = 0;
		reset = 1;
		#50;
		reset = 0;
	end
	always #10 clk = ~clk;
endmodule

"""


tbtxt6 = """`timescale 1ns / 1ps
module generated_mips_test;

    reg clk;
    reg reset;

    wire [31:0] i_inst_addr;
    wire [31:0] i_inst_rdata;

    wire [31:0] m_data_addr;
    wire [31:0] m_data_rdata;
    wire [31:0] m_data_wdata;
    wire [3 :0] m_data_byteen;

    wire [31:0] m_inst_addr;

    wire w_grf_we;
    wire [4:0] w_grf_addr;
    wire [31:0] w_grf_wdata;

    wire [31:0] w_inst_addr;

    mips uut(
        .clk(clk),
        .reset(reset),

        .i_inst_addr(i_inst_addr),
        .i_inst_rdata(i_inst_rdata),

        .m_data_addr(m_data_addr),
        .m_data_rdata(m_data_rdata),
        .m_data_wdata(m_data_wdata),
        .m_data_byteen(m_data_byteen),

        .m_inst_addr(m_inst_addr),

        .w_grf_we(w_grf_we),
        .w_grf_addr(w_grf_addr),
        .w_grf_wdata(w_grf_wdata),

        .w_inst_addr(w_inst_addr)
    );

    integer i;
    reg [31:0] fixed_addr;
    reg [31:0] fixed_wdata;
    reg [31:0] data[0:4095];
    reg [31:0] inst[0:4095];

    assign m_data_rdata = data[m_data_addr >> 2];
    assign i_inst_rdata = inst[(i_inst_addr - 32'h3000) >> 2];

    initial begin
        $readmemh("code.txt", inst);
        for (i = 0; i < 4096; i = i + 1) data[i] <= 0;
    end

    initial begin
        clk = 0;
        reset = 1;
        #20 reset = 0;
    end

    always @(*) begin
        fixed_wdata = data[m_data_addr >> 2];
        fixed_addr = m_data_addr & 32'hfffffffc;
        if (m_data_byteen[3]) fixed_wdata[31:24] = m_data_wdata[31:24];
        if (m_data_byteen[2]) fixed_wdata[23:16] = m_data_wdata[23:16];
        if (m_data_byteen[1]) fixed_wdata[15: 8] = m_data_wdata[15: 8];
        if (m_data_byteen[0]) fixed_wdata[7 : 0] = m_data_wdata[7 : 0];
    end

    always @(posedge clk) begin
		if (~reset) begin
            if (w_grf_we && (w_grf_addr != 0)) begin
                $display("%d@%h: $%d <= %h", $time, w_inst_addr, w_grf_addr, w_grf_wdata);
            end
        end
        if (reset) for (i = 0; i < 4096; i = i + 1) data[i] <= 0;
        else if (|m_data_byteen) begin
            data[fixed_addr >> 2] <= fixed_wdata;
            $display("%d@%h: *%h <= %h", $time, m_inst_addr, fixed_addr, fixed_wdata);
        end
    end

    always #10 clk <= ~clk;

endmodule

"""

tbtxt7 = """`timescale 1ns/1ps
module generated_mips_test;

	reg clk;
	reg reset;
	reg interrupt;

	wire [31:0] macroscopic_pc;

	wire [31:0] i_inst_addr;
	wire [31:0] i_inst_rdata;

	wire [31:0] m_data_addr;
	wire [31:0] m_data_rdata;
	wire [31:0] m_data_wdata;
	wire [3 :0] m_data_byteen;

	wire [31:0] m_int_addr;
	wire [3 :0] m_int_byteen;

	wire [31:0] m_inst_addr;

	wire		w_grf_we;
	wire [4 :0] w_grf_addr;
	wire [31:0] w_grf_wdata;

	wire [31:0] w_inst_addr;

	mips uut(
		.clk(clk),
		.reset(reset),
		.interrupt(interrupt),
		.macroscopic_pc(macroscopic_pc),

		.i_inst_addr(i_inst_addr),
		.i_inst_rdata(i_inst_rdata),

		.m_data_addr(m_data_addr),
		.m_data_rdata(m_data_rdata),
		.m_data_wdata(m_data_wdata),
		.m_data_byteen(m_data_byteen),

		.m_int_addr(m_int_addr),
		.m_int_byteen(m_int_byteen),

		.m_inst_addr(m_inst_addr),

		.w_grf_we(w_grf_we),
		.w_grf_addr(w_grf_addr),
		.w_grf_wdata(w_grf_wdata),

		.w_inst_addr(w_inst_addr)
	);

	initial begin
		clk <= 0;
		reset <= 1;
		interrupt <= 0;
		#20 reset <= 0;
	end

	integer i;
	reg [31:0] fixed_addr;
	reg [31:0] fixed_wdata;
	reg [31:0] data[0:4095];
	reg [31:0] inst[0:5119];

	// ----------- For Instructions -----------

	assign m_data_rdata = data[(m_data_addr >> 2) % 5120];
	assign i_inst_rdata = inst[((i_inst_addr - 32'h3000) >> 2) % 5120];

	initial begin
		$readmemh("code.txt", inst);
		for (i = 0; i < 5120; i = i + 1) data[i] <= 0;
	end

	// ----------- For Data Memory -----------

	always @(*) begin
		fixed_wdata = data[(m_data_addr >> 2) & 4095];
		fixed_addr = m_data_addr & 32'hfffffffc;
		if (m_data_byteen[3]) fixed_wdata[31:24] = m_data_wdata[31:24];
		if (m_data_byteen[2]) fixed_wdata[23:16] = m_data_wdata[23:16];
		if (m_data_byteen[1]) fixed_wdata[15: 8] = m_data_wdata[15: 8];
		if (m_data_byteen[0]) fixed_wdata[7 : 0] = m_data_wdata[7 : 0];
	end

	always @(posedge clk) begin
        if (~reset) begin
			if (w_grf_we && (w_grf_addr != 0)) begin
				$display("%d@%h: $%d <= %h", $time, w_inst_addr, w_grf_addr, w_grf_wdata);
			end
		end
		if (reset) for (i = 0; i < 4096; i = i + 1) data[i] <= 0;
		else if (|m_data_byteen && fixed_addr >> 2 < 4096) begin
			data[fixed_addr >> 2] <= fixed_wdata;
			$display("%d@%h: *%h <= %h", $time, m_inst_addr, fixed_addr, fixed_wdata);
		end
	end

	always #2 clk <= ~clk;

endmodule
"""


# 生成数据
def make_data(dataMakerPath, outPath):
    cmd = [
        "java",
        "-jar",
        dataMakerPath,
        ">",
        outPath
    ]
    os.system(" ".join(cmd))


# mars翻译为十六进制
def mips_to_hex(marsPath, asmPath, hexPath):
    cmd = [
        "java",
        "-jar",
        marsPath,
        asmPath,
        "db",
        "nc",
        "mc LargeText",
        "a",
        # "ex",
        "dump",
        ".text",
        "HexText",
        hexPath,
    ]
    os.system(" ".join(cmd))


# 利用魔改mars得到正确结果
def get_mars_output(marsPath, asmPath, marsOutputPath, tempPath):
    t1 = Thread(target=try_task, args=(marsPath, asmPath, tempPath))
    t1.start()
    time.sleep(1.5)
    # print("start copy")
    task2(marsOutputPath, tempPath)


@func_set_timeout(50)
def task(marsPath, asmPath, tempPath, mode):
    cmd56 = [
        "java",
        "-jar",
        marsPath,
        asmPath,
        "db",
        "nc",
        "lg",
        "mc LargeText",
        ">",
        tempPath,
    ]

    cmd7 = [
        "java",
        "-jar",
        marsPath,
        asmPath,
        "db",
        "nc",
        "lg",
        "ex",
        "mc LargeText",
        ">",
        tempPath,
    ]
    if mode == 7 :
        os.system(" ".join(cmd7))
    else :
        os.system(" ".join(cmd56))
    txt = ""
    with open(tempPath, 'r') as f :
        for line in f: 
            if '$' not in line :
                txt += line
            elif int(line.split('$')[1].split('<')[0]) != 0 :
                txt += line
    
    with open(tempPath, 'w') as f :
        f.write(txt)


def try_task(marsPath, asmPath, tempPath):
    try:
        task(marsPath, asmPath, tempPath)
    except func_timeout.exceptions.FunctionTimedOut:
        print("mars运行超时, 强制中途暂停")
        pro = "taskkill /im java.exe /f"
        os.system(pro)


def task2(marsOutputPath, tempPath):
    txt = ""
    with open(tempPath, "r") as f:
        for line, i in zip(f, range(MAXN)):
            txt += line
    with open(marsOutputPath, "w") as f:
        f.write(txt)
    os.remove(tempPath)


def load_files(hexPath, projectPath, mode):
    load_tb(projectPath, mode)
    load_code_txt(hexPath, projectPath)
    load_prj(projectPath)
    load_tcl(projectPath)


# 将hex文件导入CPU文件夹中的code.txt
def load_code_txt(fromPath, toPath):
    file_data = ""
    with open(fromPath, "r") as f:
        for line in f:
            file_data += line
    f.close()

    with open(toPath + "code.txt", "w") as f:
        f.write(file_data)
    f.close()


# 修正prj文件 添加tcl, mips_test
def load_prj(projectPath):
    titles = []
    for root, dirs, files in os.walk(projectPath, topdown=True):
        titles = files
        break
    titles = [x for x in titles if x.split(".")[1] == "v"]

    prjtxt = ""
    for title in titles:
        prjtxt += "verilog work " + '"' + projectPath + title + '"\n'

    with open(projectPath + "mips.prj", "w") as f:
        f.write(prjtxt)

def load_tcl(projectPath):
    tcltxt = """run {}us;
    exit
    """.format(
        100
    )
    with open(projectPath + "mips.tcl", "w") as f:
        f.write(tcltxt)


def load_tb(projectPath, mode):
    with open(projectPath + "generated_mips_test.v", "w") as f:
        if (mode == 5) :
            f.write(tbtxt5)
        elif mode == 6 :
            f.write(tbtxt6)
        else :
            f.write(tbtxt7)


# 运行仿真
def execute_ise(projectPath, xilinxPath, outputPath):
    os.chdir(projectPath)
    os.environ["XILINX"] = xilinxPath  # 设置环境变量
    os.system(
        xilinxPath
        + "bin/nt64/fuse -nodebug -prj mips.prj -o mips.exe generated_mips_test > mips.log"
    )  # 编译
    os.system("mips.exe -nolog -tclbatch mips.tcl >" + outputPath)  # 运行


# 处理result文件
def cope_cpu_out_file(cpuOutputPath):
    file_data = ""
    file_data1 = []
    with open(cpuOutputPath, "r") as f:
        for line in f:
            if "@" in line:
                file_data += "@" + line.split("@")[1]
                file_data1.append(int(line.split("@")[0]))

    with open(cpuOutputPath, "w") as f:
        f.write(file_data + "\n")
    return file_data1[-1] / 20


# 比对输出
def find_diffs(file1Path, file2Path, outputPath):
    with open(file1Path, "r") as f1:
        with open(file2Path, "r") as f2:
            text1 = f1.readlines()
            text2 = f2.readlines()

    d = difflib.HtmlDiff()
    htmlContent = d.make_file(text1, text2)
    with open(outputPath, "w") as f:
        f.write(htmlContent)

    return difflib.SequenceMatcher(None, text1, text2).ratio()
    # os.system(outputPath)


# 测试点覆盖率测试
def cal_coverage(hexPath, name):
    if os.path.isdir("work"):
        shutil.rmtree("work")
    os.makedirs("work")
    txt = ""
    with open(hexPath, "r") as f:
        for line in f.readlines():
            txt += line
    with open("work/code.txt", "w") as f:
        f.write(txt)

    os.chdir("work/")
    zip = zipfile.ZipFile("code.zip", "w", zipfile.ZIP_DEFLATED)
    zip.write("code.txt")
    os.remove("code.txt")
    zip = zipfile.ZipFile(name + ".zip", "w", zipfile.ZIP_DEFLATED)
    zip.write("code.zip")
    os.remove("code.zip")
